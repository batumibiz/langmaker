<?php
// Text
$_['text_model']        = 'Modèle';
$_['text_subscription'] = 'Abonnement';
$_['text_points']       = 'Points de Récompenses';

// Column
$_['column_product']    = 'Produit';
$_['column_quantity']   = 'Quantité';
$_['column_price']      = 'Prix unitaire';
$_['column_total']      = 'Total';

/*
 * LM REMOVED
 * These keys were redundant and were removed.
 */
// $_['text_subscription_trial'] = '%s tous les %d %s(s) pour %d paiement(s) puis ';
// $_['text_subscription_duration'] = '%s tous les %d %s(s) pour %d paiement(s)';
// $_['text_subscription_cancel'] = '%s tous les %d %s(s) jusqu\'à annulation';
