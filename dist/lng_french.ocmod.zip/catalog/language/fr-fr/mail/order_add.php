<?php
// Text
$_['text_subject']               = '%s - Commande %s';
$_['text_greeting']              = 'Merci pour votre intérêt pour les produits %s. Votre commande a été reçue et sera traitée une fois le paiement confirmé.';
$_['text_link']                  = 'Pour consulter votre commande, cliquez sur le lien ci-dessous:';
$_['text_order_detail']          = 'Détails de la commande';
$_['text_instruction']           = 'Instructions';
$_['text_order_id']              = 'ID de la commande:';
$_['text_date_added']            = 'Date d\'ajout:';
$_['text_order_status']          = 'Statut de la commande:';
$_['text_payment_method']        = 'Méthode de paiement:';
$_['text_shipping_method']       = 'Méthode d\'expédition:';
$_['text_email']                 = 'E-mail:';
$_['text_telephone']             = 'Téléphone:';
$_['text_ip']                    = 'Adresse IP:';
$_['text_payment_address']       = 'Adresse de facturation';
$_['text_shipping_address']      = 'Adresse d\'expédition';
$_['text_products']              = 'Produits';
$_['text_product']               = 'Produit';
$_['text_model']                 = 'Modèle';
$_['text_quantity']              = 'Quantité';
$_['text_price']                 = 'Prix';
$_['text_order_total']           = 'Totaux de la commande';
$_['text_total']                 = 'Total';
$_['text_subscription']          = 'Abonnement';
$_['text_subscription_duration'] = '%s tous les %d %s pour %d paiement(s)';
$_['text_subscription_cancel']   = '%s tous les %d %s jusqu\'à annulation';
$_['text_day']                   = 'jour';
$_['text_week']                  = 'semaine';
$_['text_semi_month']            = 'demi-mois';
$_['text_month']                 = 'mois';
$_['text_year']                  = 'année';
$_['text_download']              = 'Une fois votre paiement confirmé, vous pouvez cliquer sur le lien ci-dessous pour accéder à vos produits téléchargeables:';
$_['text_comment']               = 'Les commentaires pour votre commande sont:';
$_['text_footer']                = 'Veuillez répondre à cet e-mail si vous avez des questions.';

/*
 * LM REMOVED
 * These keys were redundant and were removed.
 */
// $_['text_subscription_trial'] = '%s tous les %d %s(s) pour %d paiement(s) puis ';
