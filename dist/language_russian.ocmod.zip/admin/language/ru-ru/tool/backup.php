<?php
// Heading
$_['heading_title']      = 'Бэкап / Восстановление';

// Text
$_['text_success']       = 'Задание выполнено!';
$_['text_progress']      = 'Прогресс резервного копирования';
$_['text_backup']        = 'Резервное копирование таблицы %s . Обработано записей %s . Всего записей %s';
$_['text_restore']       = 'Восстановление %s из %s';
$_['text_option']        = 'Таблицы экспорта данных';
$_['text_history']       = 'История резервного копирования';
$_['text_import']        = 'Для больших файлов резервных копий лучше загружать SQL-файл по FTP в каталог <strong>~/storage/backup/</strong>.';

// Column
$_['column_filename']    = 'Название';
$_['column_size']        = 'Размер';
$_['column_date_added']  = 'Дата';
$_['column_action']      = 'Действие';

// Entry
$_['entry_progress']     = 'Прогресс';
$_['entry_export']       = 'Экспорт';

// Error
$_['error_permission']   = 'Внимание: у вас нет разрешения на изменения в разделе Бэкап / Восстановление !';
$_['error_table']        = 'Таблица %s отсутствует в списке разрешенных!';
$_['error_file']         = 'Файл не найден!';
$_['error_file_type']    = 'Invalid file type!';
$_['error_directory']    = 'Каталог не найден!';
$_['error_not_found']    = 'Error: Could not find file %s !';
$_['error_headers_sent'] = 'Ошибка: заголовки уже отправлены!';
$_['error_upload_size']  = 'Размер загружаемого файла не может быть больше %s!';
