<?php
// Text
$_['text_success']           = 'Вы изменили подписки!';

// Error
$_['error_customer']           = 'Внимание: Необходимо указать данные клиента!';
$_['error_payment_address']    = 'Внимание: Необходимо указать адрес оплаты!';
$_['error_payment_method']     = 'Внимание: Необходимо выбрать способ оплаты!';
$_['error_shipping_address']   = 'Внимание: Необходимо указать адрес доставки!';
$_['error_shipping_method']    = 'Внимание: Необходимо выбрать способ доставки!';
$_['error_product']            = 'Внимание: Необходимо выбрать товары!';
$_['error_stock']              = 'Внимание: Товары, отмеченные ***, недоступны в нужном количестве или отсутствуют на складе!';
$_['error_minimum']            = 'Внимание: Минимальная сумма заказа для %s составляет %s!';
$_['error_subscription']       = 'Warning: Subscription required!';
$_['error_subscription_plan']  = 'Warning: Subscription plan required!';
$_['error_call']               = 'Вызов API не найден';
