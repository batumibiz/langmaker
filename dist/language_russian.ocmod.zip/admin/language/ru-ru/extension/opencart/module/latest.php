<?php
// Heading
$_['heading_title']    = 'Новые поступления';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';
$_['text_horizontal']  = 'Горизонтальная';
$_['text_vertical']    = 'Вертикальная';

// Entry
$_['entry_name']       = 'Название модуля';
$_['entry_axis']       = 'Ориентация';
$_['entry_limit']      = 'Лимит';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Высота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';
$_['error_name']       = 'Название модуля должно содержать от 3 до 64 символов!';
$_['error_width']      = 'Введите ширину изображения!';
$_['error_height']     = 'Введите высоту изображения!';
