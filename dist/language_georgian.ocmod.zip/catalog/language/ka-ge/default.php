<?php
// Locale
$_['code']                  = 'ka';
$_['direction']             = 'ltr';
$_['date_format_short']     = 'd/m/Y';
$_['date_format_long']      = 'l dS F Y';
$_['time_format']           = 'h:i:s A';
$_['datetime_format']       = 'd/m/Y H:i:s';
$_['decimal_point']         = '.';
$_['thousand_point']        = ',';

// Text
$_['text_home']             = '<i class="fa fa-home"></i>';
$_['text_yes']              = 'დიახ';
$_['text_no']               = 'არა';
$_['text_none']             = ' --- არცერთი --- ';
$_['text_select']           = ' --- აირჩიეთ --- ';
$_['text_all']              = 'ყველა';
$_['text_all_zones']        = 'ყველა ზონა';
$_['text_pagination']       = 'ნაჩვენებია %d დან %d მდე %d (%d გვერდი)';
$_['text_loading']          = 'იტვირთება...';
$_['text_no_results']       = 'შედეგი ცარიელია!';
$_['text_just_now']         = 'მხოლოდ ახლა';
$_['text_seconds_ago']      = '%s წამის წინ';
$_['text_minute_ago']       = '%s წუთის წინ';
$_['text_minutes_ago']      = '%s წუთის წინ';
$_['text_hour_ago']         = '%s საათის წინ';
$_['text_hours_ago']        = '%s საათის წინ';
$_['text_day_ago']          = '%s დღის წინ';
$_['text_days_ago']         = '%s დღის წინ';
$_['text_week_ago']         = '%s კვირის წინ';
$_['text_weeks_ago']        = '%s კვირის წინ';
$_['text_month_ago']        = '%s თვის წინ';
$_['text_months_ago']       = '%s თვის წინ';
$_['text_year_ago']         = '%s წლის წინ';
$_['text_years_ago']        = '%s წლის წინ';

// Buttons
$_['button_address_add']    = 'მისამართის დამატება';
$_['button_back']           = 'უკან';
$_['button_continue']       = 'გაგრძელება';
$_['button_cart']           = '&nbsp;კალათაში&nbsp;';
$_['button_cancel']         = 'გაუქმება';
$_['button_compare']        = 'პროდუქცტის შედარება';
$_['button_wishlist']       = 'რჩეულთა სიაში დამატება';
$_['button_checkout']       = 'ყიდვა';
$_['button_confirm']        = 'შეკვეთის დადასტურება';
$_['button_coupon']         = 'კუპონის გამოყენება';
$_['button_delete']         = 'წაშლა';
$_['button_download']       = 'გადმოწერა';
$_['button_edit']           = 'რედაქტირება';
$_['button_filter']         = 'ქვე კატეგორიები';
$_['button_new_address']    = 'ახალი მისამართი';
$_['button_change_address'] = 'მისამართის შეცვლა';
$_['button_reviews']        = 'მიმოხილვები';
$_['button_write']          = 'მიმოხილვის დაწერა';
$_['button_login']          = 'ავტორიზაცია';
$_['button_update']         = 'განახლება';
$_['button_remove']         = 'წაშლა';
$_['button_reorder']        = 'თავიდან შეკვეთა';
$_['button_return']         = 'დაბრუნება';
$_['button_shopping']       = 'შერჩევის გაგრძელება';
$_['button_search']         = 'ძებნა';
$_['button_submit']         = 'დამატება';
$_['button_guest']          = 'სტუმრის შემოწმება';
$_['button_view']           = 'ნახვა';
$_['button_upload']         = 'ფაილის ატვირთვა';
$_['button_reward']         = 'ქულების გამოყენება';
$_['button_choose']         = 'აირჩიეთ';
$_['button_shipping']       = 'მიწოდების გამოთვლა';
$_['button_quote']          = 'ფასის მიღება';
$_['button_list']           = 'სია';
$_['button_grid']           = 'ცხრილი';
$_['button_map']            = 'რუქის ნახვა';

// Error
$_['error_exception']       = 'შეცდომის კოდი(%s): %s ფაილში %s ხაზზე %s';
$_['error_upload_1']        = 'გაფრთხილება: ატვირთული ფაილი აღემატება php.ini ფაილში მითითებულ upload_max_filesize მნიშვნელობას!';
$_['error_upload_2']        = 'გაფრთხილება: ატვირთული ფაილი აღემატება HTML ფორმაში მითითებულ MAX_FILE_SIZE მნიშვნელობას!';
$_['error_upload_3']        = 'გაფრთხილება: ფაილი მხოლოდ ნაწილობრივ აიტვირთა!';
$_['error_upload_4']        = 'გაფრთხილება: ფაილი არ აიტვირთა!';
$_['error_upload_6']        = 'გაფრთხილება: დროებითი საქაღალდე ვერ მოიძებნა!';
$_['error_upload_7']        = 'გაფრთხილება: ფაილის დისკზე ჩაწერა ვერ მოხერხდა!';
$_['error_upload_8']        = 'გაფრთხილება: ფაილის ატვირთვა შეჩერდა გაფართოების მიერ!';
$_['error_upload_999']      = 'გაფრთხილება: შეცდომის კოდი მიუწვდომელია!';
$_['error_upload_size']     = 'გაფრთხილება: ატვირთული ფაილი აღემატება %sმბ მაქსიმალურ ზომას!';
$_['error_curl']            = 'CURL: შეცდომის კოდი(%s): %s';
$_['error_session']         = 'გაფრთხილება: სესია ამოიწურა, გთხოვთ ხელახლა შეავსოთ ფორმა!';

// When doing translations only include the matching language code
// Datepicker
$_['datepicker']            = 'ka-ge';
