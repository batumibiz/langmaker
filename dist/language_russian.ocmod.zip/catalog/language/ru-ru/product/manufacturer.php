<?php
// Heading
$_['heading_title']    = 'Производители';

// Text
$_['text_brand']       = 'Производитель';
$_['text_index']       = 'Алфавитный указатель:';
$_['text_no_results']  = 'Нет ни одного товара данного производителя.';
$_['text_compare']     = 'Сравнение товаров (%s)';
$_['text_sort']        = 'Сортировка:';
$_['text_default']     = 'По умолчанию';
$_['text_name_asc']    = 'Название (А - Я)';
$_['text_name_desc']   = 'Название (Я - А)';
$_['text_price_asc']   = 'Цена (низкая &gt; высокая)';
$_['text_price_desc']  = 'Цена (высокая &gt; низкая)';
$_['text_rating_asc']  = 'Рейтинг (начиная с низкого)';
$_['text_rating_desc'] = 'Рейтинг (начиная с высокого)';
$_['text_model_asc']   = 'Модель (А - Я)';
$_['text_model_desc']  = 'Модель (Я - А)';
$_['text_limit']       = 'Показать:';
