<?php
// Text
$_['text_model']                 = 'Model';
$_['text_change_order']          = 'შეკვეთის შეცვლა';
$_['text_subscription']          = 'Subscription';
$_['text_subscription_trial']    = '%s every %d %s(s) for %d payment(s) then ';
$_['text_subscription_duration'] = '%s every %d %s(s) for %d payment(s)';
$_['text_subscription_cancel']   = '%s every %d %s(s) until canceled';
$_['text_points']                = 'Reward Points';

// Column
$_['column_product']    = 'Product';
$_['column_quantity']   = 'Quantity';
$_['column_price']      = 'Unit Price';
$_['column_total']      = 'Total';
