<?php
// Heading
$_['heading_title']      = 'Статусы подписок';

// Text
$_['text_success']       = 'Настройки успешно изменены!';
$_['text_list']          = 'Список статусов подписок';
$_['text_add']           = 'Добавить';
$_['text_edit']          = 'Редактирование';

// Column
$_['column_name']        = 'Статус подписки';
$_['column_action']      = 'Действие';

// Entry
$_['entry_name']         = 'Название статуса подписки';

// Error
$_['error_permission']   = 'У Вас нет прав для изменения статусов подписок!';
$_['error_name']         = 'Статус подписки должен быть от 3 до 32 символов!';
$_['error_default']      = 'Статус подписки не может быть исключен, поскольку он прикреплен к статусу подписки основного магазина!';
$_['error_subscription'] = 'Warning: This subscription status cannot be deleted as it is currently assigned to %s subscriptions!';
