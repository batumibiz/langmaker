<?php
// Heading
$_['heading_title']      = 'IP';

// Text
$_['text_extension']     = 'Extensions';
$_['text_fraud']         = 'Anti-Fraude';
$_['text_success']       = 'Succès: Vous avez modifié l\'Anti-Fraude IP!';
$_['text_edit']          = 'Modifier l\'Anti-Fraude IP';
$_['text_ip_add']        = 'Ajouter une adresse IP';
$_['text_ip_list']       = 'Liste de fraude d\'adresse IP';

// Column
$_['column_ip']          = 'IP';
$_['column_total']       = 'Comptes Totaux';
$_['column_date_added']  = 'Date d\'Ajout';
$_['column_action']      = 'Action';

// Entry
$_['entry_ip']           = 'IP';
$_['entry_status']       = 'Statut';
$_['entry_order_status'] = 'Statut de la Commande';

// Help
$_['help_order_status']  = 'Les clients qui ont une adresse IP bannie sur leur compte seront assignés avec le statut de cette commande et ne seront pas en mesure de compléter cette commande automatiquement.';

// Error
$_['error_permission']   = 'Attention: Vous n\'avez pas la permission de modifier l\'Anti-Fraude IP!';
$_['error_required']     = 'L\'adresse IP est requise!';
$_['error_invalid']      = 'L\'adresse IP est invalide!';
