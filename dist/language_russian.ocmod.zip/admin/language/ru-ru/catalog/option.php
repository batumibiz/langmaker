<?php
// Heading
$_['heading_title']      = 'Опции';

// Text
$_['text_success']       = 'Настройки успешно изменены!';
$_['text_list']          = 'Список опций';
$_['text_add']           = 'Добавить';
$_['text_edit']          = 'Редактирование';
$_['text_choose']        = 'Выбор';
$_['text_select']        = 'Список';
$_['text_radio']         = 'Переключатель';
$_['text_checkbox']      = 'Флажок';
$_['text_input']         = 'Поле ввода';
$_['text_text']          = 'Текст';
$_['text_textarea']      = 'Текстовая область';
$_['text_file']          = 'Файл';
$_['text_date']          = 'Дата';
$_['text_datetime']      = 'Дата и время';
$_['text_time']          = 'Время';
$_['text_regex']         = 'Regex';
$_['text_option']        = 'Опция';
$_['text_value']         = 'Значение';

// Column
$_['column_name']        = 'Опция';
$_['column_sort_order']  = 'Порядок сортировки';
$_['column_action']      = 'Действие';

// Entry
$_['entry_name']         = 'Название опции';
$_['entry_type']         = 'Тип';
$_['entry_validation']   = 'Validation';
$_['entry_option_value'] = 'Значение опции';
$_['entry_image']        = 'Изображение';
$_['entry_sort_order']   = 'Порядок сортировки';

// Help
$_['help_regex']         = 'Use regex. E.g: /[^a-zA-Z0-9_-]/';

// Error
$_['error_warning']      = 'Внимание: Проверьте форму на наличие ошибок!';
$_['error_permission']   = 'У вас не достаточно прав для изменения опции!';
$_['error_name']         = 'Имя опции должно содержать от 1 до 128 символов!';
$_['error_type']         = 'Не указано значение опции!';
$_['error_option_value'] = 'Значение опции должно содержать от 1 до 128 символов!';
$_['error_value']        = 'Внимание: Данное значение опции нельзя удалить, так как назначена к %s товарам!';
$_['error_product']      = 'Внимание: Данную опцию нельзя удалить, так как назначена к %s товарам!';
