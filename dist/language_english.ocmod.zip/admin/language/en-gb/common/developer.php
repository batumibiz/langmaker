<?php
// Heading
$_['heading_title']          = 'Developer Options';

// Text
$_['text_developer_success'] = 'Success: You have modified developer settings!';
$_['text_systemcache_success'] = 'Success: You have cleared the system cache!';
$_['text_imagecache_success']  = 'Success: You have cleared the image cache!';
$_['text_sass_success']      = 'Success: You have cleared the SASS cache!';
$_['text_imagecache']        = 'Image Cache';
$_['text_sass']              = 'SASS';
$_['text_systemcache']       = 'System Cache';

// Column
$_['column_component']       = 'Component';
$_['column_action']          = 'Action';

// Entry
$_['entry_cache']            = 'Cache';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify developer settings!';
