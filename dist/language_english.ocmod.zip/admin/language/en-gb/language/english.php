<?php
// Heading
$_['heading_title']    = 'English Language';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified English language!';
$_['text_edit']        = 'Edit English Language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify English language!';
