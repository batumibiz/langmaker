<?php
// Heading
$_['heading_title']     = 'Сравнение товаров';

// Text
$_['text_product']      = 'Описание';
$_['text_name']         = 'Товар';
$_['text_image']        = 'Изображение';
$_['text_price']        = 'Цена';
$_['text_model']        = 'Модель';
$_['text_manufacturer'] = 'Производитель';
$_['text_availability'] = 'Наличие';
$_['text_instock']      = 'Есть на складе';
$_['text_rating']       = 'Рейтинг';
$_['text_reviews']      = 'Всего отзывов: %s';
$_['text_summary']      = 'Краткое описание';
$_['text_weight']       = 'Вес';
$_['text_dimension']    = 'Размеры (Д х Ш х В)';
$_['text_compare']      = 'Сравнение товаров (%s)';
$_['text_success']      = 'Товар <a href="%s">%s</a> добавлен в ваш <a href="%s">список сравнения</a>!';
$_['text_remove']       = 'Удалено из списка сравнений';
$_['text_no_results']   = 'Вы не выбрали ни одного товара для сравнения.';

// Error
$_['error_product']     = 'Внимание: Товар не найден!';
