<?php
// Heading
$_['heading_title']      = 'მისამართების წიგნი';

// Text
$_['text_account']       = 'ანგარიში';
$_['text_address_book']  = 'მისამართები';
$_['text_address_add']   = 'მისამართის დამატება';
$_['text_address_edit']  = 'მისამართის რედაქტირება';
$_['text_add']           = 'მისამართი დამატებულია';
$_['text_edit']          = 'მისამართი განახლებულია';
$_['text_delete']        = 'მისამართი წაშლილია';
$_['text_no_results']    = 'თქვენ არ გაქვთ მისამართები თქვენს ანგარიშში.';
$_['text_default']       = 'ნაგულისხმევი';

// Entry
$_['entry_firstname']    = 'სახელი';
$_['entry_lastname']     = 'გვარი';
$_['entry_company']      = 'კომპანია';
$_['entry_address_1']    = 'მისამართი 1';
$_['entry_address_2']    = 'მისამართი 2';
$_['entry_postcode']     = 'საფოსტო კოდი';
$_['entry_city']         = 'ქალაქი';
$_['entry_country']      = 'ქვეყანა';
$_['entry_zone']         = 'რეგიონი';
$_['entry_default']      = 'საწყისი მისამართი';

// Error
$_['error_token']        = 'Warning: Address token invalid!';
$_['error_subscription'] = 'Warning: Address is still being used by %s active subscriptions!';
$_['error_default']      = 'Warning: Default address required!';
$_['error_delete']       = 'Warning: You must have at least one address!';
$_['error_firstname']    = 'First Name must be between 1 and 32 characters!';
$_['error_lastname']     = 'Last Name must be between 1 and 32 characters!';
$_['error_address_1']    = 'Address must be between 3 and 128 characters!';
$_['error_postcode']     = 'Postcode must be between 2 and 10 characters!';
$_['error_city']         = 'City must be between 2 and 128 characters!';
$_['error_country']      = 'Please select a country!';
$_['error_zone']         = 'Please select a region / state!';
$_['error_custom_field'] = '%s required!';
$_['error_regex']        = '%s is not a valid input!';
