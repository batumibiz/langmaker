<?php
// Heading
$_['heading_title']              = 'Подписки';

// Text
$_['text_success']               = 'Настройки успешно изменены!';
$_['text_list']                  = 'Список подписок';
$_['text_add']                   = 'Добавить подписку';
$_['text_edit']                  = 'Подписка (#%s)';
$_['text_filter']                = 'Фильтр';
$_['text_date_added']            = 'Дата';
$_['text_order_id']              = '№ заказа';
$_['text_order']                 = 'Заказы';
$_['text_product_add']           = 'Добавить товар';
$_['text_model'] 			     = 'Модель';
$_['text_subscription']          = 'Подписка';
$_['text_remaining']             = 'Осталось';
$_['text_subscription_trial']    = '%s каждый %d %s(й) для %d платежа(й) затем';
$_['text_subscription_duration'] = '%s каждый %d %s(й) для %d платежа(й)';
$_['text_subscription_cancel']   = '%s каждый %d %s(й) пока не отменят';
$_['text_day']                   = 'День';
$_['text_week']                  = 'Неделя';
$_['text_semi_month']            = 'Полмесяца';
$_['text_month']                 = 'Месяц';
$_['text_year']                  = 'Год';
$_['text_payment_method']        = 'Способ оплаты';
$_['text_payment']               = 'Пожалуйста, выберите предпочтительный способ оплаты для этой подписки.';
$_['text_shipping_method']       = 'Способ доставки';
$_['text_shipping']              = 'Пожалуйста, выберите предпочтительный способ доставки для этой подписки.';
$_['text_history']               = 'История';
$_['text_history_add']           = 'Добавить историю';
$_['text_log']                   = 'Логи';

// Column
$_['column_subscription_id']     = '№ Подписки';
$_['column_order_id']            = '№ Заказа';
$_['column_customer']            = 'Клиент';
$_['column_comment']             = 'Комментарий';
$_['column_notify']              = 'Уведомить клиента';
$_['column_status']              = 'Статус';
$_['column_date_added']          = 'Дата';
$_['column_product']             = 'Товар';
$_['column_model']               = 'Модель';
$_['column_quantity']            = 'Количество';
$_['column_price']               = 'Цена';
$_['column_total']               = 'Total';
$_['column_amount']              = 'Сумма';
$_['column_code']                = 'Код';
$_['column_description']         = 'Описание';
$_['column_action']              = 'Действие';

// Entry
$_['entry_subscription_id']      = '№ Подписки';
$_['entry_order_id']             = '№ Заказа';
$_['entry_customer']             = 'Клиент';
$_['entry_store']                = 'Магазин';
$_['entry_language']             = 'Язык';
$_['entry_currency']             = 'Валюта';
$_['entry_subscription_plan']    = 'План подписки';
$_['entry_date_next']            = 'Следующая дата';
$_['entry_comment']              = 'Комментарий';
$_['entry_notify']               = 'Уведомить клиента';
$_['entry_date_from']            = 'Дата от';
$_['entry_date_to']              = 'Дата до';
$_['entry_subscription_status']  = 'Статус подписки';
$_['entry_product']              = 'Выберите товар';
$_['entry_option']               = 'Выберите опцию(и)';
$_['entry_quantity']             = 'Количество';
$_['entry_payment_address']      = 'Адрес оплаты';
$_['entry_shipping_address']     = 'Адрес доставки';

// Tab
$_['tab_order']                  = 'Заказы';

// Error
$_['error_permission']           = 'Внимание: У вас нет разрешения на изменение подписок!';
$_['error_subscription_status']  = 'Внимание: Необходимо выбрать статус подписки!';
$_['error_payment_method']       = 'Внимание: Способ оплаты не существует!';
$_['error_subscription']         = 'Внимание: Подписка не существует!';
